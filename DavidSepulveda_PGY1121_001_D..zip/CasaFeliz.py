import os
import numpy as np
import funet3 as fn
piso=np.empty([10,4],type(int))
depa=np.empty([10,4],type(int))
rut=[]
fn.llenar(piso,depa)

os.system("cls")
op=0
while(op!=5):
    os.system("cls")
    print("1. Comprar departamento")
    print("2. Mostrar departamentos disponibles")
    print("3. Ver listado de compradores")
    print("4. Mostrar ganancias totales")
    print("5. Salir")
    op=fn.valop()
    if(op==1):
        dd=fn.validaPiso()
        td=fn.tipodepart()
        fn.mostrarDisponibles(depa)
        fn.compraDepa()
        os.system("pause")
        
    if(op==2):
        print("*** departamentos disponibles ***")
        fn.mostrarDisponibles(piso)
        os.system("pause")
    if(op==5):
        os.system("cls")
        print("*** Hasta luego David Sepúlveda, gracias por ocupar mi sistema el dia de hoy 11/07/2023 ***")